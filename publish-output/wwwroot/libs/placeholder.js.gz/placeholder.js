// Placeholder file to satisfy ABP libs check
// This file prevents the "wwwroot/libs folder does not exist or empty" error
console.log('ABP libs placeholder loaded');

